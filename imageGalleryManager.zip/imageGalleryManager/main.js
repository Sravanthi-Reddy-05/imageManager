document.getElementById('addImageButton').addEventListener('click', function() {
    var imageUrl = document.getElementById('imageUrl').value;
    var imageGallery = document.getElementById('imageGallery');

    // Clear the input field
    document.getElementById('imageUrl').value = '';

    // Check if the URL is not empty
    if (imageUrl) {
        // Create a new div for the image item
        var imageItem = document.createElement('div');
        imageItem.classList.add('image-item');

        // Create a new image element
        var img = document.createElement('img');
        img.src = imageUrl;
        img.alt = "Image could not be loaded";

        // Create a delete button
        var deleteButton = document.createElement('button');
        deleteButton.classList.add('delete-button');
        deleteButton.innerText = 'Delete';
        
        // Append image and button to the image item div
        imageItem.appendChild(img);
        imageItem.appendChild(deleteButton);

        // Append the image item div to the gallery
        imageGallery.appendChild(imageItem);

        // Add delete functionality
        deleteButton.addEventListener('click', function() {
            imageGallery.removeChild(imageItem);
        });
    } else {
        alert('Please enter a valid image URL');
    }
});
